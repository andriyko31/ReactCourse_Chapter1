import ToDoContainer from "./container/toDoContainer/ToDoContainer";
import './App.css';



function App() {
  return (
    <>
      <ToDoContainer />
    </>
  )
}

export default App
